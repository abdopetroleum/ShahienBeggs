from distutils.core import setup

setup(
  name = 'ShahienBeggs',
  packages = ['ShahienBeggs'],
  version = '1',  # Ideally should be same as your GitHub release tag varsion
  description = 'description',
  author = 'Abdulrhman Shahien',
  author_email = 'abdopetroleum@gmail.com',
  url = 'https://github.com/abdopetroleum/ShahienBeggs',
  download_url = 'https://github.com/abdopetroleum/ShahienBeggs/archive/refs/tags/1.tar.gz',
  keywords = ['tag1', 'tag2'],
  classifiers = [],
)